# Check current working directory
getwd()

# List files in current directory
list.files()

# List files in Downloads folder
list.files("C:/Users/PascalOkai/Downloads")

# Check if the file exists
file.exists("Netflix_shows_movies_cleaned.csv")


# netflix_analysis.R
# R script for Netflix data visualization
# This creates the ratings distribution chart in R

# Load required libraries
library(ggplot2)
library(dplyr)
library(readr)

# Set working directory 
setwd("C:/Users/PascalOkai/Downloads")

# Function to create ratings distribution visualization in R
create_ratings_chart_r <- function() {
  # Read the cleaned dataset
  netflix_data <- read_csv("Netflix_shows_movies_cleaned.csv")
  
  # Check available columns
  print("Available columns:")
  print(colnames(netflix_data))
  
  # Detect rating column such as common names in Netflix datasets
  rating_columns <- c("rating", "age_rating", "maturity_rating")
  rating_col <- NULL
  
  for (col in rating_columns) {
    if (col %in% colnames(netflix_data)) {
      rating_col <- col
      break
    }
  }
  
  if (is.null(rating_col)) {
    # If no standard rating column found, we try to find any column that might contain ratings
    potential_ratings <- grep("rating|age|maturity", colnames(netflix_data), ignore.case = TRUE, value = TRUE)
    if (length(potential_ratings) > 0) {
      rating_col <- potential_ratings[1]
    } else {
      stop("No suitable rating column found in the dataset")
    }
  }
  
  print(paste("Using column for ratings:", rating_col))
  
  # Create ratings count
  ratings_count <- netflix_data %>%
    group_by(!!sym(rating_col)) %>%
    summarise(count = n()) %>%
    arrange(desc(count))
  
  # Creating the visualization
  p <- ggplot(ratings_count, aes(x = reorder(!!sym(rating_col), count), y = count, fill = !!sym(rating_col))) +
    geom_bar(stat = "identity", alpha = 0.8) +
    geom_text(aes(label = count), hjust = -0.2, size = 3.5) +
    coord_flip() +
    labs(
      title = "Netflix Content Ratings Distribution (R Visualization)",
      subtitle = "Distribution of different rating categories",
      x = "Rating Categories",
      y = "Number of Titles",
      fill = "Ratings"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
      plot.subtitle = element_text(size = 12, hjust = 0.5),
      axis.text = element_text(size = 10),
      legend.position = "none"
    ) +
    scale_fill_viridis_d()  # Using viridis color palette
  
  # We display the plot
  print(p)
  
  # Save the plot
  ggsave("ratings_distribution_r.png", plot = p, width = 12, height = 8, dpi = 300)
  
  print("R visualization saved as 'ratings_distribution_r.png'")
  
  # Print summary statistics
  print("Ratings Summary:")
  print(ratings_count)
}

# Here is the function to create genre visualization in R
create_genre_chart_r <- function() {
  # Read the data
  netflix_data <- read_csv("Netflix_shows_movies_cleaned.csv")
  
  # Detect genre column
  genre_columns <- c("genre", "genres", "listed_in", "category")
  genre_col <- NULL
  
  for (col in genre_columns) {
    if (col %in% colnames(netflix_data)) {
      genre_col <- col
      break
    }
  }
  
  if (is.null(genre_col)) {
    stop("No suitable genre column found")
  }
  
  print(paste("Using column for genres:", genre_col))
  
  # Spliting multiple genres and count
  all_genres <- netflix_data %>%
    pull(!!sym(genre_col)) %>%
    as.character() %>%
    strsplit(", |;|\\|") %>%
    unlist() %>%
    trimws()
  
  genre_count <- data.frame(genre = all_genres) %>%
    group_by(genre) %>%
    summarise(count = n()) %>%
    arrange(desc(count)) %>%
    head(10)  # Top 10 genres
  
  # Creating the visualization
  p <- ggplot(genre_count, aes(x = reorder(genre, count), y = count, fill = genre)) +
    geom_bar(stat = "identity", alpha = 0.8) +
    geom_text(aes(label = count), hjust = -0.2, size = 3.5) +
    coord_flip() +
    labs(
      title = "Top 10 Most Common Genres on Netflix (R Visualization)",
      x = "Genres",
      y = "Count"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
      legend.position = "none"
    ) +
    scale_fill_brewer(palette = "Set3")
  
  print(p)
  ggsave("genres_r.png", plot = p, width = 12, height = 8, dpi = 300)
  
  print("Genre visualization saved as 'genres_r.png'")
}

# Main execution
tryCatch({
  print("Starting Netflix Data Analysis in R")
  create_ratings_chart_r()
  # create_genre_chart_r()  # Uncomment to also create genre chart in R
  print("R analysis completed successfully!")
}, error = function(e) {
  print(paste("Error in R analysis:", e$message))
  print("Make sure the cleaned CSV file exists in the working directory")
})
